﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IconsList : MonoBehaviour
{
    public Sprite[] iconsArray;

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
}
